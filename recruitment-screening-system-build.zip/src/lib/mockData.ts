import { Candidate, JobDescription } from "../types";

export const mockJobs: JobDescription[] = [
  {
    id: "jd1",
    title: "Senior Full Stack Engineer",
    company: "TechNova Solutions",
    description: "We are looking for a Senior Full Stack Engineer with 5+ years of experience in React, Node.js, and cloud infrastructure. You will be responsible for architecting scalable web applications and mentoring junior developers.",
    requirements: ["React", "Node.js", "TypeScript", "AWS", "SQL", "5+ years experience"],
  },
  {
    id: "jd2",
    title: "Product Marketing Manager",
    company: "Growthly",
    description: "Join our marketing team to lead product launches and develop go-to-market strategies. You should have experience in B2B SaaS and strong analytical skills.",
    requirements: ["B2B SaaS", "Product Launch", "Data Analysis", "Strategy", "Communication"],
  }
];

export const mockCandidates: Candidate[] = [
  {
    id: "c1",
    name: "Alex Rivera",
    email: "alex.rivera@example.com",
    resumeText: "Experienced Full Stack Developer with 7 years in the industry. Expert in React, TypeScript, and Node.js. Successfully deployed 20+ apps on AWS. Strong background in database optimization and team leadership.",
    skills: ["React", "TypeScript", "Node.js", "AWS", "PostgreSQL", "Leadership"],
    experience: 7,
    education: "B.S. Computer Science",
    location: "San Francisco, CA",
  },
  {
    id: "c2",
    name: "Samantha Chen",
    email: "s.chen@example.com",
    resumeText: "Marketing professional with 4 years experience in SaaS. Passionate about product growth and customer engagement. Skilled in HubSpot, Google Analytics, and SEO. Led 3 successful product launches.",
    skills: ["Marketing", "HubSpot", "Google Analytics", "SaaS", "Content Strategy"],
    experience: 4,
    education: "MBA in Marketing",
    location: "Remote",
  },
  {
    id: "c3",
    name: "Jordan Smith",
    email: "jordan.s@example.com",
    resumeText: "Junior Web Developer eager to learn. Knowledge of HTML, CSS, JavaScript, and basic React. Recently completed a coding bootcamp and built several portfolio projects.",
    skills: ["HTML", "CSS", "JavaScript", "React"],
    experience: 1,
    education: "Full Stack Bootcamp",
    location: "New York, NY",
  },
  {
    id: "c4",
    name: "Elena Rodriguez",
    email: "elena.r@example.com",
    resumeText: "Senior DevOps Engineer with a focus on AWS and Kubernetes. 10 years experience in automation and CI/CD pipelines. Proficient in Python and Go.",
    skills: ["AWS", "Kubernetes", "Docker", "CI/CD", "Python", "Go"],
    experience: 10,
    education: "M.S. Software Engineering",
    location: "Austin, TX",
  }
];
