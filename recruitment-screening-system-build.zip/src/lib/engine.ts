import { Candidate, JobDescription, MatchResult } from "../types";

export const screenCandidate = (candidate: Candidate, job: JobDescription): MatchResult => {
  // Simulate "Compression" by extracting only essential tokens
  const compressedCandidate = `ID:${candidate.id}|SKILLS:${candidate.skills.join(",")}|EXP:${candidate.experience}y|EDU:${candidate.education}`;
  const compressedJob = `JD:${job.id}|REQ:${job.requirements.join(",")}|TITLE:${job.title}`;

  // Simulate Matching Algorithm
  const matchingSkills = candidate.skills.filter(skill => 
    job.requirements.some(req => req.toLowerCase().includes(skill.toLowerCase()))
  );
  
  const missingSkills = job.requirements.filter(req => 
    !candidate.skills.some(skill => req.toLowerCase().includes(skill.toLowerCase()))
  );

  const score = Math.round((matchingSkills.length / job.requirements.length) * 100);
  
  // Calculate simulated costs
  const standardCost = 0.05; 
  const optimizedCost = 0.005; 

  let reasoning = "";
  if (score > 80) {
    reasoning = `${candidate.name} is an exceptional match with deep expertise in ${matchingSkills.slice(0, 3).join(", ")}.`;
  } else if (score > 50) {
    reasoning = `${candidate.name} has a solid foundation but lacks specific experience in ${missingSkills.slice(0, 2).join(", ")}.`;
  } else {
    reasoning = `${candidate.name} does not meet the core requirements for this role.`;
  }

  return {
    candidateId: candidate.id,
    jobId: job.id,
    score,
    reasoning,
    matchingSkills,
    missingSkills,
    estimatedCost: standardCost,
    optimizedCost: optimizedCost,
    compressedResume: compressedCandidate,
    compressedJD: compressedJob,
  };
};
