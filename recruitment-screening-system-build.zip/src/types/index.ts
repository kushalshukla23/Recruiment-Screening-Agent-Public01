export interface Candidate {
  id: string;
  name: string;
  email: string;
  resumeText: string;
  skills: string[];
  experience: number;
  education: string;
  location: string;
  compressedData?: string;
}

export interface JobDescription {
  id: string;
  title: string;
  company: string;
  description: string;
  requirements: string[];
  compressedData?: string;
}

export interface MatchResult {
  candidateId: string;
  jobId: string;
  score: number;
  reasoning: string;
  missingSkills: string[];
  matchingSkills: string[];
  estimatedCost: number; // Cost using standard screening
  optimizedCost: number; // Cost using our compression
  compressedResume: string;
  compressedJD: string;
}
