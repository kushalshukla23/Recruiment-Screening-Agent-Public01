import { Search, Mail, MapPin, Briefcase, FileText } from "lucide-react";
import { Card, Button, Badge } from "@/components/ui";
import { mockCandidates } from "@/lib/mockData";

export const Candidates = () => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Candidate Pool</h1>
          <p className="text-slate-500">Manage and view all incoming resumes.</p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search candidates..." 
              className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 w-64"
            />
          </div>
          <Button className="gap-2">
            <FileText className="w-4 h-4" /> Upload Resume
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockCandidates.map(candidate => (
          <Card key={candidate.id} className="p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xl">
                {candidate.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">{candidate.name}</h3>
                <div className="flex flex-wrap gap-y-1 gap-x-4 mt-1">
                  <span className="flex items-center gap-1.5 text-sm text-slate-500">
                    <Mail className="w-3.5 h-3.5" /> {candidate.email}
                  </span>
                  <span className="flex items-center gap-1.5 text-sm text-slate-500">
                    <MapPin className="w-3.5 h-3.5" /> {candidate.location}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-slate-400" />
                <span className="text-sm font-medium text-slate-700">{candidate.experience} Years Experience</span>
              </div>
              
              <div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Skills</div>
                <div className="flex flex-wrap gap-2">
                  {candidate.skills.map(skill => (
                    <Badge key={skill}>{skill}</Badge>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                <Button variant="ghost" size="sm">View Full Resume</Button>
                <Button variant="outline" size="sm">Add to Screening</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
