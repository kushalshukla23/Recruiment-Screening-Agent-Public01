import { useState } from "react";
import { 
  TrendingUp, 
  Users, 
  Cpu, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  Search,
  Filter
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from "recharts";
import { Card, Button, Badge } from "@/components/ui";
import { mockCandidates, mockJobs } from "@/lib/mockData";
import { screenCandidate } from "@/lib/engine";
import { MatchResult } from "@/types";
import { cn } from "@/utils/cn";

export const Dashboard = () => {
  const [selectedJob, setSelectedJob] = useState(mockJobs[0]);
  const [results, setResults] = useState<MatchResult[]>([]);
  const [isScreening, setIsScreening] = useState(false);
  const [progress, setProgress] = useState(0);

  const startScreening = () => {
    setIsScreening(true);
    setResults([]);
    setProgress(0);
    
    let current = 0;
    const interval = setInterval(() => {
      if (current < mockCandidates.length) {
        const res = screenCandidate(mockCandidates[current], selectedJob);
        setResults(prev => [...prev, res]);
        current++;
        setProgress((current / mockCandidates.length) * 100);
      } else {
        clearInterval(interval);
        setIsScreening(false);
      }
    }, 800);
  };

  const chartData = [
    { name: "Standard LLM", cost: results.reduce((acc, r) => acc + r.estimatedCost, 0) },
    { name: "RecruitAI (Compressed)", cost: results.reduce((acc, r) => acc + r.optimizedCost, 0) },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Screening Dashboard</h1>
          <p className="text-slate-500">Efficiently match candidates using compressed processing.</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" /> Filter
          </Button>
          <Button onClick={startScreening} disabled={isScreening} className="gap-2 min-w-[140px]">
            {isScreening ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Screening...
              </>
            ) : (
              <>
                <Cpu className="w-4 h-4" /> Run Screening
              </>
            )}
          </Button>
        </div>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<Users className="w-6 h-6 text-blue-500" />} 
          title="Total Candidates" 
          value={mockCandidates.length.toString()} 
          change="+12% from last week" 
        />
        <StatCard 
          icon={<Clock className="w-6 h-6 text-amber-500" />} 
          title="Time Saved" 
          value="24.5h" 
          change="This month" 
        />
        <StatCard 
          icon={<DollarSign className="w-6 h-6 text-emerald-500" />} 
          title="Cost Optimized" 
          value={`$${(results.reduce((acc, r) => acc + (r.estimatedCost - r.optimizedCost), 0)).toFixed(2)}`} 
          change="Real-time savings" 
        />
        <StatCard 
          icon={<TrendingUp className="w-6 h-6 text-indigo-500" />} 
          title="Match Quality" 
          value="89%" 
          change="+4% accuracy" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Screening Queue / Progress */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
                <Search className="w-5 h-5 text-slate-400" />
                Screening Results: <span className="text-indigo-600">{selectedJob.title}</span>
              </h3>
              <div className="text-sm font-medium text-slate-500">
                {results.length} / {mockCandidates.length} Processed
              </div>
            </div>

            {isScreening && (
              <div className="mb-8">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-600 font-medium">Batch Processing in progress...</span>
                  <span className="text-indigo-600 font-bold">{Math.round(progress)}%</span>
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className="h-full bg-indigo-500"
                  />
                </div>
              </div>
            )}

            <div className="space-y-4">
              <AnimatePresence mode="popLayout">
                {results.map((result) => {
                  const candidate = mockCandidates.find(c => c.id === result.candidateId)!;
                  return (
                    <motion.div
                      key={result.candidateId}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="p-4 rounded-xl border border-slate-100 hover:border-indigo-200 hover:bg-indigo-50/20 transition-all flex items-start gap-4"
                    >
                      <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center font-bold text-slate-600 flex-shrink-0">
                        {candidate.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <h4 className="font-bold text-slate-900">{candidate.name}</h4>
                          <Badge variant={result.score > 70 ? 'success' : result.score > 40 ? 'warning' : 'danger'}>
                            {result.score}% Match
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-500 line-clamp-2 mb-3">{result.reasoning}</p>
                        <div className="flex flex-wrap gap-2">
                          {result.matchingSkills.slice(0, 3).map(skill => (
                            <span key={skill} className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded font-medium">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <div className="text-[10px] text-slate-400">
                          Cost: <span className="line-through">${result.estimatedCost}</span> <span className="text-emerald-600 font-bold">${result.optimizedCost}</span>
                        </div>
                        <Button variant="outline" size="sm">Profile</Button>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {!isScreening && results.length === 0 && (
                <div className="py-20 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="w-8 h-8 text-slate-300" />
                  </div>
                  <h3 className="text-slate-900 font-semibold">No Active Screening</h3>
                  <p className="text-slate-500 text-sm max-w-xs mx-auto mt-1">
                    Select a job description and click "Run Screening" to start the AI matching engine.
                  </p>
                </div>
              )}
            </div>
          </Card>
        </div>

        {/* Cost Analysis & Job Detail */}
        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="font-bold text-slate-900 mb-6 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-indigo-500" />
              Efficiency Report
            </h3>
            
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                  <YAxis hide />
                  <Tooltip 
                    cursor={{ fill: 'transparent' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-slate-900 text-white p-2 rounded shadow-xl text-xs">
                            ${payload[0].value?.toFixed(3)}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="cost" radius={[4, 4, 0, 0]}>
                    {chartData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={index === 0 ? '#cbd5e1' : '#6366f1'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            
            <div className="mt-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
              <h4 className="text-indigo-900 font-bold text-sm mb-1">Compression Engine Active</h4>
              <p className="text-indigo-700 text-xs leading-relaxed">
                By tokenizing resumes and removing redundant boilerplate, RecruitAI reduces LLM context window usage by <span className="font-bold">88%</span> without compromising accuracy.
              </p>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-bold text-slate-900 mb-4">Select Role</h3>
            <div className="space-y-2">
              {mockJobs.map(job => (
                <button
                  key={job.id}
                  onClick={() => setSelectedJob(job)}
                  className={cn(
                    "w-full text-left p-4 rounded-xl border transition-all",
                    selectedJob.id === job.id 
                      ? "border-indigo-500 bg-indigo-50/50 ring-1 ring-indigo-500" 
                      : "border-slate-100 hover:border-slate-300 bg-white"
                  )}
                >
                  <div className="font-bold text-slate-900">{job.title}</div>
                  <div className="text-xs text-slate-500">{job.company}</div>
                </button>
              ))}
            </div>
            
            <div className="mt-6">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Key Requirements</h4>
              <div className="flex flex-wrap gap-2">
                {selectedJob.requirements.map(req => (
                  <span key={req} className="px-2 py-1 bg-slate-100 text-slate-600 rounded text-[10px] font-medium">
                    {req}
                  </span>
                ))}
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, title, value, change }: { icon: React.ReactNode, title: string, value: string, change: string }) => (
  <Card className="p-6">
    <div className="flex items-center gap-4">
      <div className="p-3 bg-slate-50 rounded-2xl">{icon}</div>
      <div>
        <div className="text-xs text-slate-500 font-medium">{title}</div>
        <div className="text-2xl font-bold text-slate-900 tracking-tight">{value}</div>
        <div className="text-[10px] text-emerald-600 font-bold flex items-center gap-1 mt-0.5">
          <CheckCircle2 className="w-3 h-3" /> {change}
        </div>
      </div>
    </div>
  </Card>
);
