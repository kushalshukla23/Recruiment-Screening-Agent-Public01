import { Plus, Building2, Users } from "lucide-react";
import { Card, Button, Badge } from "@/components/ui";
import { mockJobs } from "@/lib/mockData";

export const Jobs = () => {
  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Job Descriptions</h1>
          <p className="text-slate-500">Manage your active job openings and requirements.</p>
        </div>
        <Button className="gap-2">
          <Plus className="w-4 h-4" /> Create New Job
        </Button>
      </header>

      <div className="grid grid-cols-1 gap-6">
        {mockJobs.map(job => (
          <Card key={job.id} className="p-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-4 max-w-2xl">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">{job.title}</h3>
                    <p className="text-slate-500">{job.company}</p>
                  </div>
                </div>
                
                <p className="text-slate-600 text-sm leading-relaxed">{job.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {job.requirements.map(req => (
                    <Badge key={req} variant="default">{req}</Badge>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-3 min-w-[200px]">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-slate-500">Total Applicants</span>
                    <Users className="w-4 h-4 text-slate-400" />
                  </div>
                  <div className="text-2xl font-bold text-slate-900">128</div>
                </div>
                <Button variant="secondary" className="w-full">Screen Candidates</Button>
                <Button variant="outline" className="w-full">Edit JD</Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
