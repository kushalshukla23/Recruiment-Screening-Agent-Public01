import { LayoutDashboard, Users, FileText, Settings, Zap } from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { cn } from "@/utils/cn";

export const Navbar = () => {
  const location = useLocation();

  const navItems = [
    { name: "Dashboard", icon: LayoutDashboard, path: "/" },
    { name: "Candidates", icon: Users, path: "/candidates" },
    { name: "Job Descriptions", icon: FileText, path: "/jobs" },
    { name: "Settings", icon: Settings, path: "/settings" },
  ];

  return (
    <nav className="fixed left-0 top-0 h-full w-64 bg-slate-900 text-white p-6 border-r border-slate-800">
      <div className="flex items-center gap-3 mb-12">
        <div className="bg-indigo-500 p-2 rounded-lg">
          <Zap className="w-6 h-6" />
        </div>
        <span className="text-xl font-bold tracking-tight">RecruitAI</span>
      </div>

      <div className="space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.name}
            to={item.path}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
              location.pathname === item.path
                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20"
                : "text-slate-400 hover:bg-slate-800 hover:text-white"
            )}
          >
            <item.icon className={cn(
              "w-5 h-5 transition-colors",
              location.pathname === item.path ? "text-white" : "text-slate-500 group-hover:text-white"
            )} />
            <span className="font-medium">{item.name}</span>
          </Link>
        ))}
      </div>

      <div className="absolute bottom-8 left-6 right-6">
        <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/50">
          <div className="text-xs text-slate-500 mb-1 uppercase tracking-wider font-semibold">Credits Used</div>
          <div className="flex items-end justify-between mb-2">
            <span className="text-lg font-bold text-white">420</span>
            <span className="text-xs text-indigo-400 font-medium">10,000 Total</span>
          </div>
          <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
            <div className="bg-indigo-500 h-full w-[4.2%]" />
          </div>
          <p className="text-[10px] text-slate-500 mt-2 italic">
            Savings: $243.50 saved this month
          </p>
        </div>
      </div>
    </nav>
  );
};
