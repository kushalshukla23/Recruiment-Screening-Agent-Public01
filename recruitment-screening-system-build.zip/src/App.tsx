import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Navbar } from "./components/layout/Navbar";
import { Dashboard } from "./pages/Dashboard";
import { Candidates } from "./pages/Candidates";
import { Jobs } from "./pages/Jobs";

export function App() {
  return (
    <Router>
      <div className="flex min-h-screen bg-slate-50">
        <Navbar />
        <main className="flex-1 ml-64 p-10 overflow-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/candidates" element={<Candidates />} />
            <Route path="/jobs" element={<Jobs />} />
            <Route path="/settings" element={<div className="p-8">Settings Page (Coming Soon)</div>} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}
